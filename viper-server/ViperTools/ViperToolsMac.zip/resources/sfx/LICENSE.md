We thank the following authors from [freesound.org](https://freesound.org): 
* **suntemple** for [magic.mp3](https://freesound.org/people/suntemple/sounds/241809/), [bonus-pickup.wav](https://freesound.org/people/suntemple/sounds/253172/), [falling-down.wav](https://freesound.org/people/suntemple/sounds/253173/) 
* **josepharaoh99** for [engine-dying.mp3](https://freesound.org/people/josepharaoh99/sounds/368512/). 

The sound effects in Viper IDE are licensed under [CC0](https://creativecommons.org/publicdomain/zero/1.0/).
